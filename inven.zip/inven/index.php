<?php
session_start();

if(!isset($_SESSION['userId']))  
{
  header('location:login.php');
}
?>

<?php require "assets/function.php" ?>
<?php require 'assets/db.php';?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo siteTitle(); ?></title>
  <?php require "assets/autoloader.php" ?>

  <style type="text/css">
  <?php include 'css/customStyle.css'; ?>
  </style>
   <link rel="stylesheet" href="js/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo siteTitle(); ?></title>
  <?php require "assets/autoloader.php" ?>
  <style type="text/css">
#categoryChart1, #categoryChart2, #categoryChart3 {
  color: greenyellow;
  position: fixed;
  left: 270px;  
  width: 200px;
  height: 170px;
  margin-bottom: 50px;
}

#categoryChart2 {
  bottom: 200px;
}

#categoryChart3 {
  top: 460px;
}

.dashboard {
  position: fixed;
  width: 15%;
  height: 100%;
  background: #222D32;
  overflow-y: auto;  
  overflow-x: hidden;
  transition: width 0.3s ease;
}

.dashboard:hover {
  width: 18%;
}

.dashboard a {
  color: white;
  text-decoration: none;
  display: block;
  padding: 8px 12px;
  transition: background-color 0.3s, color 0.3s, padding-left 0.3s;
}

.dashboard a:hover {
  background-color: #3C8DBC;
  color: yellowgreen;
  padding-left: 20px;
}

.dashboard .item ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dashboard .item ul li {
  padding: 8px 12px;
  transition: background-color 0.3s, padding-left 0.3s;
}

.dashboard .item ul li:hover {
  background-color: #1E282C;
  padding-left: 20px;
}

.dashboard .item ul li a {
  color: white;
}

.center img {
  transition: transform 0.3s, box-shadow 0.3s;
}

.center img:hover {
  transform: scale(1.1);
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

.box2 {
  transition: transform 0.3s, box-shadow 0.3s;
  margin: 5px;
}

.box2:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.rightAccount {
  padding-right: 5px;
  padding: 5px;
  cursor: pointer;
  transition: color 0.3s;
}

.rightAccount:hover {
  color: yellowgreen;
}

.account {
  display: none;
  position: absolute;
  right: 10px;
  background: white;
  width: 200px;
  border: 1px solid #ccc;
  z-index: 1000;
  transition: opacity 0.3s ease;
  opacity: 0;
}

.account.show {
  display: block;
  opacity: 1;
}

.content2 {
  margin-left: 15%;
  padding: 10px;
  transition: margin-left 0.3s ease;
}

.dashboard:hover ~ .content2 {
  margin-left: 18%;
}

.box2 {
  width: 23%;
  display: inline-block;
  margin: 10px 1%;
  vertical-align: top;
}

  </style>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>



<body style="background: #ECF0F5;padding:0;margin:0">

<div class="dashboard" style="position: fixed;width: 18%;height: 100%;background:#222D32">

  <div style="background:#357CA5;padding: 14px 3px;color:white;font-size: 15pt;text-align: center;text-shadow: 1px 1px 11px black">
  <i class="fa fa-medkit" style="font-size:25px;color:red"></i>

    <a href="index.php" style="color: white;text-decoration: none;"><?php echo strtoupper(siteName());
      ?> 
  </a>
  </div>



  <div style="background: #1A2226;font-size: 10pt;padding: 11px;color: #79978F">MAIN NAVIGATION</div>
  <div>
    <div style="background:#1E282C;color: white;padding: 13px 17px;border-left: 3px solid #3C8DBC;"><span><i style="font-size:18px;color:yellowgreen" class="fa">&#xf0e4;</i> Dashboard</span></div>
    <div class="item">
      <ul class="nostyle zero">
        <a href="index.php"><li><i class="fas fa-home fa-fw"></i> Home</li></a>
        <a href="inventeries.php"><li style="color: white"><i class="fas fa-archive fa-fw"></i> Inventories</li></a>
        <a href="expire.php"><li style="color: white"><i class="fas fa-hourglass-end fa-fw"></i> Expired Items</li></a>
        <a href="addnew.php"><li><i class="fas fa-plus-circle fa-fw"></i> Add New Item</li></a>
        <a href="reports.php"><li><i class="fas fa-chart-bar fa-fw"></i> Report</li></a>
      </ul>
    </div>
  </div>
  <div style="background:#1E282C;color: white;padding: 13px 17px;border-left: 3px solid #3C8DBC;"><span><i class="fa fa-globe fa-fw"></i> Other Menu</span></div>
  <div class="item">
    <ul class="nostyle zero">
      <a href="sitesetting.php"><li style="color: white"><i class="fas fa-cogs fa-fw"></i> Site Setting</li></a>
      <a href="profile.php"><li><i class="fas fa-user-circle fa-fw"></i> Profile Setting</li></a>
      <a href="accountSetting.php"><li><i class="fas fa-user-cog fa-fw"></i> Account Setting</li></a>
      <a href="logout.php"><li><i class="fas fa-sign-out-alt fa-fw"></i> Sign Out</li></a>
    </ul>
    </div>
</div>



<div class="marginLeft" >
 <div style="color:white;background:#3C8DBC" >
    <div class="pull-right flex rightAccount" style="padding-right: 11px;padding: 7px;">
      <div><img src="photo/<?php echo $user['pic'] ?>" style='width: 41px;height: 33px;' class='img-circle'></div>
      <div style="padding: 8px"><?php echo ucfirst($user['name']) ?></div>
    </div>
    <div class="clear"></div>
  </div>
<div class="account" style="display: none;">
  <div style="background: #3C8DBC;padding: 22px;" class="center">
    <img src="photo/<?php echo $user['pic'] ?>" style='width: 100px;height: 100px; margin:auto;' class='img-circle img-thumbnail'>
    <br><br>
    <span style="font-size: 13pt;color:#CEE6F0"><?php echo $user['name'] ?></span><br>
    <span style="color: #CEE6F0;font-size: 10pt">Member Since:<?php echo $user['date']; ?></span>
  </div>
  <div style="padding: 11px;">
    <a href="profile.php"><button class="btn btn-default" style="border-radius:0">Profile</button>
    <a href="logout.php"><button class="btn btn-default pull-right" style="border-radius: 0">Sign Out</button></a>
  </div>
</div>
<!---------------BODY-------------->

  <div class="content2">
    <div>
      <span style="font-size: 16pt;color: #333333;margin-left:13px">Categories </span>
      <a href="manageCat.php"><button class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addIn"><i class="fa fa-gear  fa-fw"> </i> Manage Categories</button></a>

    </div>
    
<!-----Display categories as boxes------->
  <?php 
    $array = $con->query("select * from categories");
    while ($row = $array->fetch_assoc()) 
    {
      $array2 = $con->query("select count(*) from inventeries where catId = '$row[id]'");
      $row2 = $array2->fetch_assoc();
  ?>
    <a href="inventeries.php?catId=<?php echo $row['id'] ?>"><div class="box2 col-md-2">
     <div class="center"> <img src="photo/<?php echo $row['pic'] ?>" style="width: 155px;height: 122px;" class='img-thumbnail'></div>
      <hr style="margin: 7px;">
      <span style="padding: 11px"><strong style="font-size: 10pt">Name</strong><span class="pull-right" style="color:blue;margin-right: 11px;"><?php echo $row['name'] ?></span></span>
      <hr style="margin: 7px;">
      <span style="padding: 11px"><strong style="font-size: 10pt">Available Qty</strong><span class="pull-right" style="color:blue;margin-right: 11px"><?php echo $row2['count(*)']; ?></span></span>
    </div></a>
  <?php
    }
   ?>
  </div>
</div>
<canvas id="categoryChart1"></canvas>
  <canvas id="categoryChart2"></canvas>
  <canvas id="categoryChart3"></canvas>

</body>
</html>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    // PHP code to fetch data for the first graph
    <?php
      $labels1 = [];
      $data1 = [];
      $array1 = $con->query("SELECT * FROM categories");
      while ($row1 = $array1->fetch_assoc()) {
        $array2 = $con->query("SELECT COUNT(*) as count FROM inventeries WHERE catId = '$row1[id]'");
        $row2 = $array2->fetch_assoc();
        $labels1[] = $row1['name'];
        $data1[] = $row2['count'];
      }
    ?>

    // Chart data for the first graph
    var categoryData1 = {
      labels: <?php echo json_encode($labels1); ?>,
      datasets: [{
        label: 'Items in Categories',
        data: <?php echo json_encode($data1); ?>,
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
      }]
    };

    // Create the first chart
    var ctx1 = document.getElementById('categoryChart1').getContext('2d');
    var myChart1 = new Chart(ctx1, {
      type: 'doughnut',
      data: categoryData1,
      options: {
        responsive: false,
        plugins: {
          legend: {
            position: 'right',
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.parsed !== null) {
                  label += context.parsed;
                }
                return label;
              }
            }
          }
        }, animation: {
        duration: 2000,
        
        loop:true // Adjust animation duration for chart 3
      }
      }
    });

    // PHP code to fetch data for the second graph
    <?php
      $labels2 = [];
      $data2 = [];
      $array3 = $con->query("SELECT * FROM categories");
      while ($row3 = $array3->fetch_assoc()) {
        $array4 = $con->query("SELECT COUNT(*) as count FROM inventeries WHERE catId = '$row3[id]'");
        $row4 = $array4->fetch_assoc();
        $labels2[] = $row3['name'];
        $data2[] = $row4['count'];
      }
    ?>

    
    var categoryData2 = {
      labels: <?php echo json_encode($labels2); ?>,
      datasets: [{
        label: 'Items in Categories',
        data: <?php echo json_encode($data2); ?>,
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
      }]
    };

    
    var ctx2 = document.getElementById('categoryChart2').getContext('2d');
    var myChart2 = new Chart(ctx2, {
      type: 'line', 
      data: categoryData2,
      options: {
        responsive: false,
        plugins: {
          legend: {
            position: 'right',
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.parsed !== null) {
                  label += context.parsed;
                }
                return label;
              }
            }
          }
        }, animation: {
        duration: 2000,
        loop:true
      }
      }
    });

    
    <?php
      $labels3 = [];
      $data3 = [];
      $array4 = $con->query("SELECT * FROM categories");
      while ($row4 = $array4->fetch_assoc()) {
        $array5 = $con->query("SELECT COUNT(*) as count FROM inventeries WHERE catId = '$row4[id]'");
        $row5 = $array5->fetch_assoc();
        $labels3[] = $row4['name'];
        $data3[] = $row5['count'];
      }
    ?>

   
    var categoryData3 = {
      labels: <?php echo json_encode($labels3); ?>,
      datasets: [{
        label: 'Items in Categories',
        data: <?php echo json_encode($data3); ?>,
        backgroundColor: 'rgba(153, 102, 255, 0.2)',
        borderColor: 'rgba(153, 102, 255, 1)',
        borderWidth: 1
      }]
    };

    
    var ctx3 = document.getElementById('categoryChart3').getContext('2d');
    var myChart3 = new Chart(ctx3, {
      type: 'bar',
      data: categoryData3,
      options: {
        responsive: false,
        plugins: {
          legend: {
            position: 'right',
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.parsed !== null) {
                  label += context.parsed;
                }
                return label;
              }
            }
          }
        }, animation: {
        duration: 2000,
        loop:true
        
      }
      }
    });
  });
</script>


<script type="text/javascript">
  $(document).ready(function(){$(".rightAccount").click(function(){$(".account").fadeToggle();});});
</script>
