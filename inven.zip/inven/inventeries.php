<?php
session_start();

if (!isset($_SESSION['userId'])) {
    header('location:login.php');
    exit();
}

require "assets/function.php";
require 'assets/db.php';

// Handle deletion request for an inventory item
if (isset($_GET['deleteId'])) {
    $deleteId = $_GET['deleteId'];
    
    // Delete item from the inventeries table
    $deleteQuery = "DELETE FROM inventeries WHERE id = ?";
    $stmt = $con->prepare($deleteQuery);
    $stmt->bind_param("i", $deleteId);
    $stmt->execute();
    
    header('Location: inventeries.php');
    exit();
}


$inventoryQuery = "SELECT id, name, unit, price, quantity, expiry_date, supplier, company FROM inventeries";
$inventoryResult = $con->query($inventoryQuery);
?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
#categoryChart1, #categoryChart2, #categoryChart3 {
  color: greenyellow;
  position: fixed;
  left: 270px;  
  width: 180px;
  height: 170px;
  margin-bottom: 50px;
}

#categoryChart2 {
  bottom: 200px;
}

#categoryChart3 {
  top: 460px;
}

.dashboard {
  position: fixed;
  width: 15%;
  height: 100%;
  background: #222D32;
  overflow-y: auto;  /* Enable vertical scrollbar */
  overflow-x: hidden;
  transition: width 0.3s ease;
}

.dashboard:hover {
  width: 18%;
}

.dashboard a {
  color: white;
  text-decoration: none;
  display: block;
  padding: 8px 12px;
  transition: background-color 0.3s, color 0.3s, padding-left 0.3s;
}

.dashboard a:hover {
  background-color: #3C8DBC;
  color: yellowgreen;
  padding-left: 20px;
}

.dashboard .item ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dashboard .item ul li {
  padding: 8px 12px;
  transition: background-color 0.3s, padding-left 0.3s;
}

.dashboard .item ul li:hover {
  background-color: #1E282C;
  padding-left: 20px;
}

.dashboard .item ul li a {
  color: white;
}

.center img {
  transition: transform 0.3s, box-shadow 0.3s;
}

.center img:hover {
  transform: scale(1.1);
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

.box2 {
  transition: transform 0.3s, box-shadow 0.3s;
  margin: 5px;
}

.box2:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.rightAccount {
  padding-right: 5px;
  padding: 5px;
  cursor: pointer;
  transition: color 0.3s;
}

.rightAccount:hover {
  color: yellowgreen;
}

.account {
  display: none;
  position: absolute;
  right: 10px;
  background: white;
  width: 200px;
  border: 1px solid #ccc;
  z-index: 1000;
  transition: opacity 0.3s ease;
  opacity: 0;
}

.account.show {
  display: block;
  opacity: 1;
}

.content2 {
  margin-left: 15%;
  padding: 10px;
  transition: margin-left 0.3s ease;
}

.dashboard:hover ~ .content2 {
  margin-left: 18%;
}

.box2 {
  width: 23%;
  display: inline-block;
  margin: 10px 1%;
  vertical-align: top;
}

  </style>
    <link rel="stylesheet" href="js/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title><?php echo siteTitle(); ?></title>
    <?php require "assets/autoloader.php"; ?>
    <style type="text/css">
        <?php include 'css/customStyle.css'; ?>
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background: #ECF0F5; padding:0; margin:0">
<div class="dashboard" style="position: fixed; width: 18%; height: 100%; background:#222D32">
    <div style="background:#357CA5; padding: 14px 3px; color:white; font-size: 15pt; text-align: center; text-shadow: 1px 1px 11px black">
        <i class="fa fa-medkit" style="font-size:25px;color:red"></i>
        <a href="index.php" style="color: white; text-decoration: none;"><?php echo strtoupper(siteName()); ?></a>
    </div>

    <div style="background: #1A2226; font-size: 10pt; padding: 11px; color: #79978F">MAIN NAVIGATION</div>
    <div>
        <div style="background:#1E282C; color: white; padding: 13px 17px; border-left: 3px solid #3C8DBC;">
            <span><i style="font-size:18px;color:yellowgreen" class="fa">&#xf0e4;</i> Dashboard</span>
        </div>
        <div class="item">
            <ul class="nostyle zero">
                <a href="index.php"><li><i class="fas fa-home fa-fw"></i> Home</li></a>
                <a href="inventeries.php"><li style="color: white"><i class="fas fa-archive fa-fw"></i> Inventories</li></a>
                <a href="expire.php"><li style="color: white"><i class="fas fa-hourglass-end fa-fw"></i> Expired Items</li></a>
                <a href="addnew.php"><li><i class="fas fa-plus-circle fa-fw"></i> Add New Item</li></a>
                <a href="reports.php"><li><i class="fas fa-chart-bar fa-fw"></i> Report</li></a>
            </ul>
        </div>
    </div>
    <div style="background:#1E282C; color: white; padding: 13px 17px; border-left: 3px solid #3C8DBC;">
        <span><i class="fa fa-globe fa-fw"></i> Other Menu</span>
    </div>
    <div class="item">
        <ul class="nostyle zero">
            <a href="sitesetting.php"><li style="color: white"><i class="fas fa-cogs fa-fw"></i> Site Setting</li></a>
            <a href="profile.php"><li><i class="fas fa-user-circle fa-fw"></i> Profile Setting</li></a>
            <a href="accountSetting.php"><li><i class="fas fa-user-cog fa-fw"></i> Account Setting</li></a>
            <a href="logout.php"><li><i class="fas fa-sign-out-alt fa-fw"></i> Sign Out</li></a>
        </ul>
    </div>
</div>

<div class="marginLeft">
<?php 
if (isset($_GET['catId'])) 
{
  $catId = $_GET['catId'];
  $array = $con->query("select * from categories where id='$catId'");
  $catArray =$array->fetch_assoc();
  $catName = $catArray['name'];
  $stockArray = $con->query("select * from inventeries where catId='$catArray[id]'");
 
} 
else 
{
  $catName = "All Inventeries";
  $stockArray = $con->query("select * from inventeries");
}

  include 'assets/bill.php'; // including bill file
 ?>
    <div class="content">
    <div class="search">
        <form action="" method="GET">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>
        <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><?php echo $catName ?></li></li>
        </ol>
        <div class="tableBox">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Expiry Date</th>
                        <th>Supplier</th>
                        <th>Company</th>
                        <th>Select Item</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 0;
                   
                if (isset($_GET['search'])) {
                    $search = $_GET['search'];
                   
                    $inventoryQuery = "SELECT id, name, unit, price, quantity, expiry_date, supplier, company FROM inventeries WHERE name LIKE '%$search%' OR unit LIKE '%$search%' OR supplier LIKE '%$search%' OR company LIKE '%$search%'";
                    $inventoryResult = $con->query($inventoryQuery);
                }
                    while ($row = $inventoryResult->fetch_assoc()) {
                        $i++;
                        $id = $row['id'];
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['unit']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo isset($row['expiry_date']) ? date('Y-m-d', strtotime($row['expiry_date'])) : ''; ?></td>
                        <td><?php echo $row['supplier']; ?></td>
                        <td><?php echo $row['company']; ?></td>
                        <?php 
            if (!empty($_SESSION['bill']))  
            {
             
            foreach ($_SESSION['bill'] as $key => $value) 
            {
              
              if (in_array($row['id'], $_SESSION['bill'][$key])) 
              {
                echo "<td>Selected</td>"; break;
              }            
               else
               {
              ?>
                         <?php if($row['quantity']>0){?>
              <td id='selection<?php echo $i; ?>'><button class="btn btn-primary btn-xs" onclick="addInBill('<?php echo $id ?>','<?php echo $i; ?>')">Select</button></td>
              <?php } else { ?>
                <td id='selection<?php echo $i; ?>'><button class="btn btn-primary btn-xs" onclick="addInBill('<?php echo $id ?>','<?php echo $i; ?>')" disabled>Select</button></td>
              <?php  } ?> 

              <?php break;} } 
            } 
              else          
                {?>
              <?php if($row['quantity']>0){?>
              <td id='selection<?php echo $i; ?>'><button class="btn btn-primary btn-xs" onclick="addInBill('<?php echo $id ?>','<?php echo $i; ?>')">Select</button></td>
              <?php } else { ?>
                <td id='selection<?php echo $i; ?>'><button class="btn btn-primary btn-xs" onclick="addInBill('<?php echo $id ?>','<?php echo $i; ?>')" disabled>Select</button></td>
              <?php  }} ?>
                        <td>
                        <a href="delete.php?item=<?php echo $row['id'] ?>&url=<?php echo $_SERVER['QUERY_STRING'] // it contains information such as headers, paths, and script locations
              ?>"><button class='btn btn-danger btn-xs'>Delete Item</button></a></td>
 <td colspan="center"><a href="addnew.php?item=<?php echo $row['id'] ?>"><button class='btn btn-success btn-xs'>Edit</button></a></td>
              <td colspan="center">
                            
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
 


        </div>
    </div>
</div>
<script src="js/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="js/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
  function addInBill(id,place)
  { 
    var value = $("#counter").val();
    value ++;
    var selection = 'selection'+place;
    $("#bill").fadeIn();
    $("#counter").val(value);
    $("#"+selection).html("selected");
    $.post('called.php?q=addtobill',
               {
                   id:id
               }
        );

  }
  function addInBill(id, place) {
        var value = $("#counter").val();
        value++;
        var selection = 'selection' + place;
        $("#bill").fadeIn();
        $("#counter").val(value);
        $("#" + selection).html("selected");
        $.post('called.php?q=addtobill', {
            id: id
        });
    }
  
</script>

</body>
</html>
