<?php
session_start();

if (!isset($_SESSION['userId'])) {
    header('location:login.php');
}
?>
<?php require "assets/function.php"; ?>
<?php require 'assets/db.php'; ?>
<!DOCTYPE html>
<html>
<head> <style type="text/css">
#categoryChart1, #categoryChart2, #categoryChart3 {
  color: greenyellow;
  position: fixed;
  left: 270px;  /* Adjusted position */
  width: 200px;
  height: 170px;
  margin-bottom: 50px;
}

#categoryChart2 {
  bottom: 200px;
}

#categoryChart3 {
  top: 460px;
}

.dashboard {
  position: fixed;
  width: 15%;
  height: 100%;
  background: #222D32;
  overflow-y: auto;  
  overflow-x: hidden;
  transition: width 0.3s ease;
}

.dashboard:hover {
  width: 18%;
}

.dashboard a {
  color: white;
  text-decoration: none;
  display: block;
  padding: 8px 12px;
  transition: background-color 0.3s, color 0.3s, padding-left 0.3s;
}

.dashboard a:hover {
  background-color: #3C8DBC;
  color: yellowgreen;
  padding-left: 20px;
}

.dashboard .item ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dashboard .item ul li {
  padding: 8px 12px;
  transition: background-color 0.3s, padding-left 0.3s;
}

.dashboard .item ul li:hover {
  background-color: #1E282C;
  padding-left: 20px;
}

.dashboard .item ul li a {
  color: white;
}

.center img {
  transition: transform 0.3s, box-shadow 0.3s;
}

.center img:hover {
  transform: scale(1.1);
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

.box2 {
  transition: transform 0.3s, box-shadow 0.3s;
  margin: 5px;
}

.box2:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.rightAccount {
  padding-right: 5px;
  padding: 5px;
  cursor: pointer;
  transition: color 0.3s;
}

.rightAccount:hover {
  color: yellowgreen;
}

.account {
  display: none;
  position: absolute;
  right: 10px;
  background: white;
  width: 200px;
  border: 1px solid #ccc;
  z-index: 1000;
  transition: opacity 0.3s ease;
  opacity: 0;
}

.account.show {
  display: block;
  opacity: 1;
}

.content2 {
  margin-left: 15%;
  padding: 10px;
  transition: margin-left 0.3s ease;
}

.dashboard:hover ~ .content2 {
  margin-left: 18%;
}

.box2 {
  width: 23%;
  display: inline-block;
  margin: 10px 1%;
  vertical-align: top;
}

  </style>
    <title><?php echo siteTitle(); ?></title>
    <?php require "assets/autoloader.php"; ?>
    <style type="text/css">
        <?php include 'css/customStyle.css'; ?>
    </style>
    <?php $notice = ""; ?>
    <link rel="stylesheet" href="js/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background: #ECF0F5; padding: 0; margin: 0">
<div class="dashboard" style="position: fixed; width: 18%; height: 100%; background: #222D32">
    <div style="background: #357CA5; padding: 14px 3px; color: white; font-size: 15pt; text-align: center; text-shadow: 1px 1px 11px black">
        <i class="fa fa-medkit" style="font-size: 25px; color: red"></i>
        <a href="index.php" style="color: white; text-decoration: none;"><?php echo strtoupper(siteName()); ?></a>
    </div>

    <div style="background: #1A2226; font-size: 10pt; padding: 11px; color: #79978F">MAIN NAVIGATION</div>
    <div>
        <div style="background: #1E282C; color: white; padding: 13px 17px; border-left: 3px solid #3C8DBC;">
            <span><i style="font-size: 18px; color: yellowgreen" class="fa">&#xf0e4;</i> Dashboard</span>
        </div>
        <div class="item">
            <ul class="nostyle zero">
                <a href="index.php"><li><i class="fas fa-home fa-fw"></i> Home</li></a>
                <a href="inventeries.php"><li style="color: white"><i class="fas fa-archive fa-fw"></i> Inventories</li></a>
                <a href="expire.php"><li style="color: white"><i class="fas fa-hourglass-end fa-fw"></i> Expired Items</li></a>
                <a href="addnew.php"><li><i class="fas fa-plus-circle fa-fw"></i> Add New Item</li></a>
                <a href="reports.php"><li><i class="fas fa-chart-bar fa-fw"></i> Report</li></a>
            </ul>
        </div>
    </div>
    <div style="background: #1E282C; color: white; padding: 13px 17px; border-left: 3px solid #3C8DBC;">
        <span><i class="fa fa-globe fa-fw"></i> Other Menu</span>
    </div>
    <div class="item">
        <ul class="nostyle zero">
            <a href="sitesetting.php"><li style="color: white"><i class="fas fa-cogs fa-fw"></i> Site Setting</li></a>
            <a href="profile.php"><li><i class="fas fa-user-circle fa-fw"></i> Profile Setting</li></a>
            <a href="accountSetting.php"><li><i class="fas fa-user-cog fa-fw"></i> Account Setting</li></a>
            <a href="logout.php"><li><i class="fas fa-sign-out-alt fa-fw"></i> Sign Out</li></a>
        </ul>
    </div>
</div>
<div class="marginLeft">
    <div style="color: white; background: #3C8DBC">
        <div class="pull-right flex rightAccount" style="padding-right: 11px; padding: 7px;">
            <div><img src="photo/<?php echo $user['pic']; ?>" style='width: 41px; height: 33px;' class='img-circle'></div>
            <div style="padding: 8px"><?php echo ucfirst($user['name']); ?></div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="account" style="display: none;">
        <div style="background: #3C8DBC; padding: 22px;" class="center">
            <img src="photo/<?php echo $user['pic']; ?>" style='width: 100px; height: 100px; margin: auto;' class='img-circle img-thumbnail'>
            <br><br>
            <span style="font-size: 13pt; color: #CEE6F0"><?php echo $user['name']; ?></span><br>
            <span style="color: #CEE6F0; font-size: 10pt">Member Since: <?php echo $user['date']; ?></span>
        </div>
        <div style="padding: 11px;">
            <a href="profile.php"><button class="btn btn-default" style="border-radius: 0">Profile</button></a>
            <a href="logout.php"><button class="btn btn-default pull-right" style="border-radius: 0">Sign Out</button></a>
        </div>
    </div>
    <?php
    if (isset($_POST['saveProduct'])) {
        if ($con->query("INSERT INTO inventeries (catId, supplier, name, unit, price, quantity, description, company, expiry_date) VALUES ('$_POST[catId]', '$_POST[supplier]', '$_POST[name]', '$_POST[unit]', '$_POST[price]', '$_POST[quantity]', '$_POST[discription]', '$_POST[company]', '$_POST[expiry_date]')")) {
            $notice = "<div class='alert alert-success'>Successfully Saved</div>";
        } else {
            $notice = "<div class='alert alert-danger'>Error is: " . $con->error . "</div>";
        }
    }

    if (isset($_POST['updateItem'])) {
        $itemID = $_GET['item'];
        if ($con->query("UPDATE inventeries SET supplier='$_POST[supplier]', name='$_POST[name]', unit='$_POST[unit]', price='$_POST[price]', quantity='$_POST[quantity]', company='$_POST[company]', expiry_date='$_POST[expiry_date]' WHERE id=$itemID")) {
            $notice = "<div class='alert alert-success'>Successfully Updated</div>";
        } else {
            $notice = "<div class='alert alert-danger'>Error is: " . $con->error . "</div>";
        }
    }

    if (isset($_GET['item'])) {
        $itemID = $_GET['item'];
        $row = $con->query("SELECT * FROM inventeries WHERE id=$itemID")->fetch_assoc();
        ?>
        <div class="content2">
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li class="active">Add New Product</li>
            </ol>
            <?php echo $notice; ?>
            <div style="width: 55%; margin: auto; padding: 22px;" class="well well-sm center">
                <h4>Add New Product</h4>
                <hr>
                <form method="POST">
                    <div class="form-group">
                        <label for="some" class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="some" value="<?php echo $row['name']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Unit</label>
                        <input type="text" name="unit" placeholder="i.e 50mg" class="form-control" id="some" value="<?php echo $row['unit']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Price Per Unit</label>
                        <input type="number" name="price" class="form-control" id="some" value="<?php echo $row['price']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" id="some" value="<?php echo $row['quantity']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="expiry_date" class="col-form-label">Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" id="expiry_date" value="<?php echo $row['expiry_date']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Supplier Name</label>
                        <input type="text" name="supplier" class="form-control" id="some" value="<?php echo $row['supplier']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Medicine Company Name</label>
                        <input type="text" name="company" class="form-control" id="some" value="<?php echo $row['company']; ?>" required>
                    </div>
                    <div class="center">
                        <button type="submit" name="updateItem" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    } else {
        ?>
        <div class="content2">
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li class="active">Add New Product</li>
            </ol>
            <?php echo $notice; ?>
            <div style="width: 55%; margin: auto; padding: 22px;" class="well well-sm center">
                <h4>Add New Product</h4>
                <hr>
                <form method="POST">
                    <div class="form-group">
                        <label for="some" class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Unit</label>
                        <input type="text" name="unit" placeholder="i.e 50mg" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Price Per Unit</label>
                        <input type="number" name="price" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="expiry_date" class="col-form-label">Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" id="expiry_date" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Supplier Name</label>
                        <input type="text" name="supplier" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Medicine Company Name</label>
                        <input type="text" name="company" class="form-control" id="some" required>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Select Category</label>
                        <select class="form-control" required name="catId">
                            <option selected disabled value="">Please Select Category</option>
                            <?php getAllCat(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="some" class="col-form-label">Description</label>
                        <textarea class="form-control" name="discription" required placeholder="Write some description"></textarea>
                    </div>
                    <div class="center">
                        <button type="submit" name="saveProduct" class="btn btn-primary">Save</button>
                        <button type="reset" class="btn btn-success">Reset</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }
    ?>
</div>
</body>
</html>

<script type="text/javascript">
    $(document).ready(function() {
        $(".rightAccount").click(function() {
            $(".account").fadeToggle();
        });
    });
</script>
